"""
ooxml-integrity - structural integrity checks for .docx files.

Two questions, both needed:

    check(path)               is this .docx self-consistent?
    compare(source, edited)   what did the edit lose relative to the source?
    check_pptx(path)          does this deck's text fit, and do shapes collide?

`Policy` carries a project's config - severity overrides, path-scoped ignores,
`fail-on` - and is what makes the checks deployable in someone else's
repository rather than only in this one.

None of them needs a model, a renderer, or the network.

    >>> from ooxml_integrity import check, compare
    >>> for f in check("edited.docx"):
    ...     print(f)
    >>> for f in compare("original.docx", "edited.docx"):
    ...     print(f)
"""
from .archive import ArchiveLimits
from .coverage import CoverageItem, CoverageReport, CoverageStatus, coverage_for
from .fidelity import TRACKED, compare
from .finding import ERROR, INFO, WARN, Finding, Severity, summarize, worst
from .inspector import Inspector, check, check_many
from .policy import Policy
from .pptx_checks import check_pptx

__version__ = "0.4.1"

__all__ = [
    "check",
    "check_many",
    "check_pptx",
    "compare",
    "Inspector",
    "Finding",
    "Severity",
    "ERROR",
    "WARN",
    "INFO",
    "summarize",
    "worst",
    "TRACKED",
    "Policy",
    "ArchiveLimits",
    "CoverageItem",
    "CoverageReport",
    "CoverageStatus",
    "coverage_for",
    "__version__",
]
